package com.yayao.bean;
/**
 * 商品收藏类
 * @author yy
 *
 */
public class MerCollection {

}
