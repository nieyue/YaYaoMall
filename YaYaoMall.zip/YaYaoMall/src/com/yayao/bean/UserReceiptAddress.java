package com.yayao.bean;
/**
 * 收货地址类
 * @author yy
 *
 */
public class UserReceiptAddress {

}
