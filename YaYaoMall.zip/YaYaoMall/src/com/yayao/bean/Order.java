package com.yayao.bean;
/**
 * 订单类
 * @author yy
 *
 */
public class Order {

}
