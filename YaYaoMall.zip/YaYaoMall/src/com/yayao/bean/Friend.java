package com.yayao.bean;
/**
 * 好友类
 * @author yy
 *
 */
public class Friend {

}
