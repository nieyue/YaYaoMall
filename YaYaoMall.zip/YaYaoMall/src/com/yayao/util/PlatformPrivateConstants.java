package com.yayao.util;

import org.springframework.cache.interceptor.SimpleKeyGenerator;

public class PlatformPrivateConstants extends SimpleKeyGenerator{

	public PlatformPrivateConstants() {
		// TODO Auto-generated constructor stub
	}
	
}
